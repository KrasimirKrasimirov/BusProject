﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BusProject.core.Models;

namespace BusProject.core.Contracts
{
    public interface IBusService
    {
        public Task<LinkedList<Seat>> GetAllAvailableSeats(int routeID, int firstStopID, int lastStopID);
        public void TakeSeat(int routeID, int firstStopID, int lastStopID,  int seatNumber);
        public Task<LinkedList<Stop>> GetAllStops();
        public Task<LinkedList<Route>> GetAllRoutes();
    }
}