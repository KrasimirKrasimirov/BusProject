﻿namespace BusProject.core.Models
{
    public class Stop
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}