﻿namespace BusProject.core.Models
{
    public class Seat
    {
        public int ID { get; set; }
        public int FirstStop { get; set; }
        public int LastStop { get; set; }
        public int RouteID { get; set; }
        public int SeatNumber { get; set; }
    }
}