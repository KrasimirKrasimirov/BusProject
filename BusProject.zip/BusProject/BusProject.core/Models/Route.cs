﻿namespace BusProject.core.Models
{
    public class Route
    {
        public int ID { get; set; }
        public int MaxSeats { get; set; }
        public int FirstStop { get; set; }
        public int LastStop { get; set; }
    }
}