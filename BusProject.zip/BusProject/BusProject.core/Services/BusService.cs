﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.SqlClient;
using BusProject.core.Contracts;
using BusProject.core.Models;

namespace BusProject.core.Services
{
    public class BusService : IBusService
    {
        const string data_source = "Krasimir"; //change according to your data source key for database connection
        public async Task<LinkedList<Seat>> GetAllAvailableSeats(int routeID, int firstStopID, int lastStopID)
        {
            LinkedList<Seat> availableSeatList = new LinkedList<Seat>();

            using (SqlConnection con = new SqlConnection(@"Data Source=" + data_source + "; Initial Catalog=BusProject; Integrated Security = True"))
            using (SqlCommand com = new SqlCommand("EXEC GetAllAvailableSeats @routeID, @selectedFirstStopID, @selectedLastStopID;", con)) 
            {
                con.Open();

                com.Parameters.Add(new SqlParameter("routeID", routeID));
                com.Parameters.Add(new SqlParameter("selectedFirstStopID", firstStopID));
                com.Parameters.Add(new SqlParameter("selectedLastStopID", lastStopID));

                SqlDataReader rdr = com.ExecuteReader();

                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        availableSeatList.AddLast(new Seat() { SeatNumber = rdr.GetInt32(0) });
                    }
                }
               
                return availableSeatList;
            }
        }

        public async void TakeSeat(int routeID, int firstStopID, int lastStopID, int seatNumber)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=" + data_source + "; Initial Catalog=BusProject; Integrated Security = True"))
            using (SqlCommand com = new SqlCommand("EXEC TakeSeat @routeId, @selectedFirstStopID, @selectedLastStopID, @seatNumber;", con))
            {
                con.Open();

                com.Parameters.Add(new SqlParameter("routeID", routeID));
                com.Parameters.Add(new SqlParameter("selectedFirstStopID", firstStopID));
                com.Parameters.Add(new SqlParameter("selectedLastStopID", lastStopID));
                com.Parameters.Add(new SqlParameter("seatNumber", seatNumber));

                com.ExecuteNonQuery();
            }
        }

        public async Task<LinkedList<Stop>> GetAllStops()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=" + data_source + "; Initial Catalog=BusProject; Integrated Security = True"))
            using (SqlCommand com = new SqlCommand("SELECT * FROM STOPS", con))
            {
                con.Open();
                LinkedList<Stop> stops = new LinkedList<Stop>();
                SqlDataReader rdr = com.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        stops.AddLast(new Stop()
                        {
                            ID = rdr.GetInt32(0),
                            Name = rdr.GetString(1).Trim()
                        });
                    }

                    return stops;
                }
                else
                {
                    return null;
                }
            }
        }

        public async Task<LinkedList<Route>> GetAllRoutes()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=" + data_source + "; Initial Catalog=BusProject; Integrated Security = True"))
            using (SqlCommand com = new SqlCommand("SELECT * FROM ROUTES", con))
            {
                con.Open();
                LinkedList<Route> routes = new LinkedList<Route>();
                SqlDataReader rdr = com.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        routes.AddLast(new Route()
                        {
                            ID = rdr.GetInt32(0),
                            MaxSeats = rdr.GetInt32(1),
                            FirstStop = rdr.GetInt32(2),
                            LastStop = rdr.GetInt32(3)
                        });
                    }

                    return routes;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}