﻿namespace BusProject.core.Enums
{
    public enum UIModCases
    {
        ROUTE_INDEX_CHANGE,
        FIRST_STOP_INDEX_CHANGE,
        LAST_STOP_INDEX_CHANGE,
        SELECT_ROUTE_BTN_CLICK,
        RESERVATION_BTN_CLICK
    }
}