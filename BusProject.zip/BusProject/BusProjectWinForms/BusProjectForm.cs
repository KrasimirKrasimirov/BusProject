﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using BusProject.core.Services;
using BusProject.core.Contracts;
using BusProject.core.Models;
using BusProject.core.Enums;

namespace BusProjectWinForms
{
    public partial class BusProjectForm : Form
    {
        private IBusService busService = new BusService();
        private DataTable dt = new DataTable();
        private LinkedList<Route> Routes { get; set; }
        private LinkedList<Stop> Stops { get; set; }
        private int FirstStopID { get; set; }
        private int LastStopID { get; set; }

        public BusProjectForm()
        {
            InitializeComponent();
            Routes = new LinkedList<Route>();
            Stops = new LinkedList<Stop>();
            FillRouteCmbFromTable(cmbSelectedRoute);
            FillStopsListFromTable();
        }

        private void FillStopCmb(ComboBox cmbStops, List<Stop> fillStopCmb)
        {
            cmbStops.Items.Clear();
            foreach(Stop stop in fillStopCmb)
            {
                cmbStops.Items.Add(stop.Name.Trim());
            }
        }

        private async void FillRouteCmbFromTable(ComboBox cmbSelectedRoute)
        {
            Routes = await busService.GetAllRoutes();
            if(Routes == null || Routes.Count == 0)
            {
                MessageBox.Show("Няма намерени маршрути");
            }
            else
            {
                foreach (Route route in Routes)
                {
                    cmbSelectedRoute.Items.Add(route.ID);
                }
            }
        }
        
        private async void FillStopsListFromTable()
        {
            if (Stops.Count == 0 || Stops == null)
            {
                Stops = await busService.GetAllStops();
            }
        }
        
        private async void btnSelectRoute_Click(object sender, EventArgs e)
        {
            Route route = Routes.Where(r => r.ID == (int)cmbSelectedRoute.SelectedItem).FirstOrDefault();
            string firstStop = cmbFirstStop.Text;
            string lastStop = cmbLastStop.Text;
            ClearDataTable();
            if (!String.IsNullOrEmpty(firstStop) && !String.IsNullOrEmpty(lastStop) && !firstStop.Equals(lastStop))
            {
                FirstStopID = Stops.Where(s => string.Equals(s.Name, firstStop)).FirstOrDefault().ID;
                LastStopID = Stops.Where(s => string.Equals(s.Name, lastStop)).FirstOrDefault().ID;
                LinkedList<Seat> availableSeats = await busService.GetAllAvailableSeats((int)cmbSelectedRoute.SelectedItem, FirstStopID, LastStopID);

                if(!dt.Columns.Contains("Място номер"))
                {
                    dt.Columns.Add("Място номер", typeof(int));
                }
                
                foreach (var seat in availableSeats)
                {
                    dt.Rows.Add(seat.SeatNumber);
                }

                ModifyUI(UIModCases.SELECT_ROUTE_BTN_CLICK);
                lblAmountOfFreeSeats.Text = "Брой свободни места: " + availableSeats.Count + " / " + route.MaxSeats;
            }
            else
            {
                ClearDataTable();
            }
        }

        private void cmbRoutes_SelectedIndexChanged(object sender, EventArgs e)
        {
            Route route = Routes.Where(r => r.ID == (int)cmbSelectedRoute.SelectedItem).FirstOrDefault();
            List<Stop> includedStops = new List<Stop>();
            if (route.FirstStop < route.LastStop)
            {
                includedStops = Stops.Where(s => Enumerable.Range(route.FirstStop, route.LastStop - route.FirstStop).Contains(s.ID)).ToList();
            }
            else if(route.FirstStop > route.LastStop)
            {
                includedStops = Stops.Where(s => Enumerable.Range(route.LastStop +1, route.FirstStop - route.LastStop).Contains(s.ID)).ToList();
            }

            FillStopCmb(cmbFirstStop, includedStops);
            ModifyUI(UIModCases.ROUTE_INDEX_CHANGE);
            lblRouteFirstLastStop.Text = (Stops.Where(s => s.ID == route.FirstStop).FirstOrDefault().Name + " - " + Stops.Where(s => s.ID == route.LastStop).FirstOrDefault().Name);
        }

        private void cmbFirstStop_SelectedIndexChanged(object sender, EventArgs e)
        {
            Route route = Routes.Where(r => r.ID == (int)cmbSelectedRoute.SelectedItem).FirstOrDefault();
            List<Stop> includedStops = new List<Stop>();

            Stop firstStop = Stops.Where(s => string.Equals(s.Name, cmbFirstStop.SelectedItem.ToString())).FirstOrDefault(); 

            if(firstStop.ID < route.LastStop)
            {
                includedStops = Stops.Where(s => Enumerable.Range(firstStop.ID + 1, route.LastStop - firstStop.ID).Contains(s.ID)).ToList();
            }
            else if(firstStop.ID > route.LastStop)
            {
                includedStops = Stops.Where(s => Enumerable.Range(route.LastStop, firstStop.ID - route.LastStop).Contains(s.ID)).ToList();
            }
            FillStopCmb(cmbLastStop, includedStops);
            ModifyUI(UIModCases.FIRST_STOP_INDEX_CHANGE);
        }

        private void cmbLastStop_SelectedIndexChanged(object sender, EventArgs e)
        {
            ModifyUI(UIModCases.LAST_STOP_INDEX_CHANGE);
        }
        
        private void btnReserveSeat_Click(object sender, EventArgs e)
        {
            if(dgvFreeSeats.SelectedCells.Count != 0)
            {
                busService.TakeSeat((int)cmbSelectedRoute.SelectedItem, FirstStopID, LastStopID, (int)dgvFreeSeats.CurrentCell.Value);
                MessageBox.Show("Вие успешно резервирахте място номер: " + (int)cmbSelectedRoute.SelectedItem + " по пътна линия: " + lblRouteFirstLastStop.Text, "Информация за резервацията");
                ModifyUI(UIModCases.RESERVATION_BTN_CLICK);
            }
        }
        
        private void ClearDataTable()
        {
            dt.Columns.Clear();
            dt.Rows.Clear();
        }
        
        private void ModifyUI(UIModCases resetCase)
        {
            switch (resetCase)
            {
                case UIModCases.ROUTE_INDEX_CHANGE:
                    cmbFirstStop.Text = string.Empty;
                    cmbLastStop.Text = string.Empty;
                    cmbFirstStop.Visible = true;
                    cmbLastStop.Visible = false;
                    lblDirection.Visible = true;
                    lblFirstStop.Visible = true;
                    lblLastStop.Visible = false;
                    lblAmountOfFreeSeats.Visible = false;
                    lblRouteFirstLastStop.Visible = true;
                    btnReserveSeat.Visible = false;
                    btnSelectRoute.Visible = false;
                    dgvFreeSeats.Visible = false;
                    break;
                case UIModCases.FIRST_STOP_INDEX_CHANGE:
                    cmbLastStop.Visible = true;
                    cmbLastStop.Text = string.Empty;
                    lblLastStop.Visible = true;
                    lblAmountOfFreeSeats.Visible = false;
                    btnReserveSeat.Visible = false;
                    btnSelectRoute.Visible = false;
                    dgvFreeSeats.Visible = false;
                    break;
                case UIModCases.LAST_STOP_INDEX_CHANGE:
                    lblAmountOfFreeSeats.Visible = false;
                    btnSelectRoute.Visible = true;
                    btnReserveSeat.Visible = false;
                    dgvFreeSeats.Visible = false;
                    break;
                case UIModCases.SELECT_ROUTE_BTN_CLICK:
                    lblAmountOfFreeSeats.Visible = true;
                    btnReserveSeat.Visible = true;
                    dgvFreeSeats.DataSource = dt;
                    dgvFreeSeats.Visible = true;
                    break;
                case UIModCases.RESERVATION_BTN_CLICK:
                    cmbSelectedRoute.Text = string.Empty;
                    cmbFirstStop.Visible = false;
                    cmbLastStop.Visible = false;
                    lblDirection.Visible = false;
                    lblFirstStop.Visible = false;
                    lblLastStop.Visible = false;
                    lblRouteFirstLastStop.Visible = false;
                    lblAmountOfFreeSeats.Visible = false;
                    btnReserveSeat.Visible = false;
                    btnSelectRoute.Visible = false;
                    dgvFreeSeats.Visible = false;
                    ClearDataTable();
                    break;
                default:
                    break;
            }
        }
    }
}