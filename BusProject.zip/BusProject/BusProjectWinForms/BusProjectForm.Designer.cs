﻿
namespace BusProjectWinForms
{
    partial class BusProjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirstStop = new System.Windows.Forms.Label();
            this.lblLastStop = new System.Windows.Forms.Label();
            this.cmbFirstStop = new System.Windows.Forms.ComboBox();
            this.cmbLastStop = new System.Windows.Forms.ComboBox();
            this.dgvFreeSeats = new System.Windows.Forms.DataGridView();
            this.btnReserveSeat = new System.Windows.Forms.Button();
            this.btnSelectRoute = new System.Windows.Forms.Button();
            this.lblRoutes = new System.Windows.Forms.Label();
            this.cmbSelectedRoute = new System.Windows.Forms.ComboBox();
            this.lblRouteFirstLastStop = new System.Windows.Forms.Label();
            this.lblDirection = new System.Windows.Forms.Label();
            this.lblAmountOfFreeSeats = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeSeats)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFirstStop
            // 
            this.lblFirstStop.AutoSize = true;
            this.lblFirstStop.Location = new System.Drawing.Point(73, 132);
            this.lblFirstStop.Name = "lblFirstStop";
            this.lblFirstStop.Size = new System.Drawing.Size(92, 13);
            this.lblFirstStop.TabIndex = 0;
            this.lblFirstStop.Text = "Начална спирка:";
            this.lblFirstStop.Visible = false;
            // 
            // lblLastStop
            // 
            this.lblLastStop.AutoSize = true;
            this.lblLastStop.Location = new System.Drawing.Point(73, 181);
            this.lblLastStop.Name = "lblLastStop";
            this.lblLastStop.Size = new System.Drawing.Size(86, 13);
            this.lblLastStop.TabIndex = 1;
            this.lblLastStop.Text = "Крайна спирка:";
            this.lblLastStop.Visible = false;
            // 
            // cmbFirstStop
            // 
            this.cmbFirstStop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFirstStop.FormattingEnabled = true;
            this.cmbFirstStop.Location = new System.Drawing.Point(215, 132);
            this.cmbFirstStop.Name = "cmbFirstStop";
            this.cmbFirstStop.Size = new System.Drawing.Size(153, 21);
            this.cmbFirstStop.TabIndex = 2;
            this.cmbFirstStop.Visible = false;
            this.cmbFirstStop.SelectedIndexChanged += new System.EventHandler(this.cmbFirstStop_SelectedIndexChanged);
            // 
            // cmbLastStop
            // 
            this.cmbLastStop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLastStop.FormattingEnabled = true;
            this.cmbLastStop.Location = new System.Drawing.Point(215, 181);
            this.cmbLastStop.Name = "cmbLastStop";
            this.cmbLastStop.Size = new System.Drawing.Size(153, 21);
            this.cmbLastStop.TabIndex = 3;
            this.cmbLastStop.Visible = false;
            this.cmbLastStop.SelectedIndexChanged += new System.EventHandler(this.cmbLastStop_SelectedIndexChanged);
            // 
            // dgvFreeSeats
            // 
            this.dgvFreeSeats.AllowUserToAddRows = false;
            this.dgvFreeSeats.AllowUserToDeleteRows = false;
            this.dgvFreeSeats.AllowUserToResizeColumns = false;
            this.dgvFreeSeats.AllowUserToResizeRows = false;
            this.dgvFreeSeats.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFreeSeats.Location = new System.Drawing.Point(574, 36);
            this.dgvFreeSeats.MultiSelect = false;
            this.dgvFreeSeats.Name = "dgvFreeSeats";
            this.dgvFreeSeats.ReadOnly = true;
            this.dgvFreeSeats.Size = new System.Drawing.Size(162, 214);
            this.dgvFreeSeats.TabIndex = 4;
            this.dgvFreeSeats.Visible = false;
            // 
            // btnReserveSeat
            // 
            this.btnReserveSeat.Location = new System.Drawing.Point(574, 296);
            this.btnReserveSeat.Name = "btnReserveSeat";
            this.btnReserveSeat.Size = new System.Drawing.Size(162, 23);
            this.btnReserveSeat.TabIndex = 5;
            this.btnReserveSeat.Text = "Резервирай място";
            this.btnReserveSeat.UseVisualStyleBackColor = true;
            this.btnReserveSeat.Visible = false;
            this.btnReserveSeat.Click += new System.EventHandler(this.btnReserveSeat_Click);
            // 
            // btnSelectRoute
            // 
            this.btnSelectRoute.Location = new System.Drawing.Point(218, 251);
            this.btnSelectRoute.Name = "btnSelectRoute";
            this.btnSelectRoute.Size = new System.Drawing.Size(150, 23);
            this.btnSelectRoute.TabIndex = 6;
            this.btnSelectRoute.Text = "Изберете маршрут";
            this.btnSelectRoute.UseVisualStyleBackColor = true;
            this.btnSelectRoute.Visible = false;
            this.btnSelectRoute.Click += new System.EventHandler(this.btnSelectRoute_Click);
            // 
            // lblRoutes
            // 
            this.lblRoutes.AutoSize = true;
            this.lblRoutes.Location = new System.Drawing.Point(73, 55);
            this.lblRoutes.Name = "lblRoutes";
            this.lblRoutes.Size = new System.Drawing.Size(72, 13);
            this.lblRoutes.TabIndex = 7;
            this.lblRoutes.Text = "Маршрут No:";
            // 
            // cmbSelectedRoute
            // 
            this.cmbSelectedRoute.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectedRoute.FormattingEnabled = true;
            this.cmbSelectedRoute.Location = new System.Drawing.Point(215, 55);
            this.cmbSelectedRoute.Name = "cmbSelectedRoute";
            this.cmbSelectedRoute.Size = new System.Drawing.Size(153, 21);
            this.cmbSelectedRoute.TabIndex = 8;
            this.cmbSelectedRoute.SelectedIndexChanged += new System.EventHandler(this.cmbRoutes_SelectedIndexChanged);
            // 
            // lblRouteFirstLastStop
            // 
            this.lblRouteFirstLastStop.AutoSize = true;
            this.lblRouteFirstLastStop.Location = new System.Drawing.Point(215, 97);
            this.lblRouteFirstLastStop.Name = "lblRouteFirstLastStop";
            this.lblRouteFirstLastStop.Size = new System.Drawing.Size(35, 13);
            this.lblRouteFirstLastStop.TabIndex = 9;
            this.lblRouteFirstLastStop.Text = "label1";
            this.lblRouteFirstLastStop.Visible = false;
            // 
            // lblDirection
            // 
            this.lblDirection.AutoSize = true;
            this.lblDirection.Location = new System.Drawing.Point(73, 97);
            this.lblDirection.Name = "lblDirection";
            this.lblDirection.Size = new System.Drawing.Size(48, 13);
            this.lblDirection.TabIndex = 10;
            this.lblDirection.Text = "Посока:";
            this.lblDirection.Visible = false;
            // 
            // lblAmountOfFreeSeats
            // 
            this.lblAmountOfFreeSeats.AutoSize = true;
            this.lblAmountOfFreeSeats.Location = new System.Drawing.Point(574, 261);
            this.lblAmountOfFreeSeats.Name = "lblAmountOfFreeSeats";
            this.lblAmountOfFreeSeats.Size = new System.Drawing.Size(0, 13);
            this.lblAmountOfFreeSeats.TabIndex = 11;
            this.lblAmountOfFreeSeats.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 401);
            this.Controls.Add(this.lblAmountOfFreeSeats);
            this.Controls.Add(this.lblDirection);
            this.Controls.Add(this.lblRouteFirstLastStop);
            this.Controls.Add(this.cmbSelectedRoute);
            this.Controls.Add(this.lblRoutes);
            this.Controls.Add(this.btnSelectRoute);
            this.Controls.Add(this.btnReserveSeat);
            this.Controls.Add(this.dgvFreeSeats);
            this.Controls.Add(this.cmbLastStop);
            this.Controls.Add(this.cmbFirstStop);
            this.Controls.Add(this.lblLastStop);
            this.Controls.Add(this.lblFirstStop);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Резервации";
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeSeats)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstStop;
        private System.Windows.Forms.Label lblLastStop;
        private System.Windows.Forms.ComboBox cmbFirstStop;
        private System.Windows.Forms.ComboBox cmbLastStop;
        private System.Windows.Forms.DataGridView dgvFreeSeats;
        private System.Windows.Forms.Button btnReserveSeat;
        private System.Windows.Forms.Button btnSelectRoute;
        private System.Windows.Forms.Label lblRoutes;
        private System.Windows.Forms.ComboBox cmbSelectedRoute;
        private System.Windows.Forms.Label lblRouteFirstLastStop;
        private System.Windows.Forms.Label lblDirection;
        private System.Windows.Forms.Label lblAmountOfFreeSeats;
    }
}

