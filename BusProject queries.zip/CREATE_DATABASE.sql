IF EXISTS(SELECT * FROM SYS.DATABASES WHERE NAME='BusProject')
DROP DATABASE [BusProject]
GO
CREATE DATABASE [BusProject]
ON
( NAME = BusProject,  
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\BusProject.mdf',
    SIZE = 10MB,
    MAXSIZE = 50MB,
    FILEGROWTH = 5MB )  
LOG ON
( NAME = BusProject_Log2,  
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\BusProjectLog.ldf',
    SIZE = 5MB,
    MAXSIZE = 25MB,
    FILEGROWTH = 5MB );
GO